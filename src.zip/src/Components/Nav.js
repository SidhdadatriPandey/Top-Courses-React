function Nav(){
    return(
        <div>
            <h2>TOP COURSES</h2>
        </div>
    )
}

export default Nav;